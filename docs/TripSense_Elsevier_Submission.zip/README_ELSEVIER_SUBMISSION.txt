TripSense-FairNet v3 (GeoFairFormer) — Elsevier LaTeX Submission Package
=======================================================================

Contents:
1. TripSense_Elsevier_2Col_Manuscript.tex  : Full camera-ready 2-column Elsevier LaTeX source
2. TripSense_Elsevier_2Col_Manuscript.bbl  : Pre-compiled BibTeX bibliography
3. TripSense_Elsevier_2Col_Manuscript.pdf  : Compiled 2-column Elsevier journal PDF
4. TripSense_Elsevier_Anonymous_Review.tex : Double-blind anonymized manuscript
5. TripSense_Elsevier_Anonymous_Review.bbl : Pre-compiled bibliography for anonymized review
6. TripSense_Elsevier_Anonymous_Review.pdf : Compiled anonymized 2-column PDF
7. references.bib                          : Complete 45-entry BibTeX database
8. Title_Page.tex & Title_Page.docx        : Separate Elsevier Title Page (author, CRediT, COI)
9. Highlights.txt & Highlights.docx        : 5 mandatory ESWA Highlights (all <= 85 characters)
10. Declaration_of_Interests.txt           : Signed Conflict of Interest statement
11. q1_figures/*.pdf & *.png               : All 10 publication figures (vector PDF + 300-DPI PNG)
